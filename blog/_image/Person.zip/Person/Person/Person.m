//
//  Person.m
//  Person
//
//  Created by Leo on 16/5/19.
//  Copyright © 2016年 Leo. All rights reserved.
//

#import "Person.h"

@interface Person ()

@end

@implementation Person
{
    int ID;
    int age;
}

-(Person *)init
{
    if (self=[super init]) {
        ID=100;
        age=23;
    }
    return self;
}

-(void)show
{
    NSLog(@"Person ID %d 年龄 %d",ID,age);
}
@end
