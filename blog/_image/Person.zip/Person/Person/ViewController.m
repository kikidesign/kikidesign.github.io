//
//  ViewController.m
//  Person
//
//  Created by Leo on 16/5/19.
//  Copyright © 2016年 Leo. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Person *person1 = [Person alloc];
    person1 = [person1 init];
    [person1 show];
    
    Person *person2 = [[Person alloc] init];
    [person2 show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
