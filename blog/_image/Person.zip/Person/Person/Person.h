//
//  Person.h
//  Person
//
//  Created by Leo on 16/5/19.
//  Copyright © 2016年 Leo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Person : NSObject

-(Person *)init;
-(void)show;

@end
